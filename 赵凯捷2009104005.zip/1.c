#include<stdio.h>
#include <string.h>

struct link
{
	char nume[10];
	int year;
};

int find(char *nume,struct link *an)
{
	for(int i = 0;i<2;i++)
	{
		int a = strcmp(nume,an[i].nume);
		if(a==0)
		{
			int a = an[i].year;
			return a;
		}
	}
	return 0;

}

int main()
{
	struct link an[3] = {
		{"̫��",227},
		{"����",233},
		{"����",237}
		
	};
	
	char nume[10];
	int year;
	int yearA;
	scanf("%s%d",&nume,&year);
	yearA = find(nume,an);
	yearA = find(nume,an) + year;
	printf("�����ǹ�Ԫ%d��",yearA);
	
	
	return 0;
}

